---
title: Vegan
short: Vegan
---
