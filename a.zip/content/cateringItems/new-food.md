---
isActive: true
name: new food
sectionRef: new-section.md
image: /uploads/placeholder.jpg
priceLabel: "52"
order: 999
---
