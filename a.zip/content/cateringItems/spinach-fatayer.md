---
isActive: true
name: Spinach Fatayer
sectionRef: cateringSections/mouajanat
image: /uploads/placeholder.jpg
priceLabel: ""
order: 1
---
Baked spinach filling with a bright lemon finish.
