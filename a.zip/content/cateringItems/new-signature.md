---
isActive: true
name: new signature
sectionRef: mouajanat.md
image: /uploads/placeholder.jpg
priceLabel: "25"
order: 999
---
