---
name: Orange Tango Cake
image: /uploads/orangeCake.png
section: vegan.md
badges:
  - organic.md
  - lactose-free.md
flavors:
  - Orange
pricing:
  type: single
  currency: USD
  price: 35
---
