---
name: Mia’s Blush Cake
image: /uploads/straweberryCake.png
section: organic.md
badges:
  - organic.md
flavors:
  - Stawberry
pricing:
  type: by_size
  currency: USD
  sizes:
    - label: 24 cm
      price: 35
    - label: 26 cm
      price: 55
---
