---
name: Golden Temptation Cake
image: /uploads/pineappleCake.png
section: organic.md
badges:
  - organic.md
flavors:
  - Pineapple
pricing:
  type: single
  currency: USD
  price: 35
---
