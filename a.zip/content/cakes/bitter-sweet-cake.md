---
name: Bitter Sweet Cake
image: /uploads/bitterSweetCake.png
section: organic.md
badges:
  - organic.md
flavors:
  - Chocolate
pricing:
  type: single
  currency: USD
  price: 35
---
