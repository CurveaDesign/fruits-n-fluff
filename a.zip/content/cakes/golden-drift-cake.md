---
name: Golden Drift Cake
image: /uploads/appleCaramelCake.png
section: organic.md
badges:
  - organic.md
flavors:
  - Apple
  - Caramel
  - cinnamon
  - walnuts
pricing:
  type: single
  currency: USD
  price: 35
---
