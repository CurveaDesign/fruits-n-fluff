---
name: Mango Overload Cake
image: /uploads/mangoCake.png
section: organic.md
badges:
  - organic.md
flavors:
  - Mango
pricing:
  type: single
  currency: USD
  price: 35
---
