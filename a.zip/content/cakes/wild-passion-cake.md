---
name: Wild Passion Cake
image: /uploads/passionFruitCake.png
section: organic.md
badges:
  - organic.md
flavors:
  - Passion Fruit
  - Sweet Melon
pricing:
  type: single
  currency: USD
  price: 35
---
