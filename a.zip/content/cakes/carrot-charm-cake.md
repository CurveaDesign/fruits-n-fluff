---
name: Carrot Charm Cake
image: /uploads/carrotCake.png
section: organic.md
badges:
  - organic.md
flavors:
  - Carrot
  - Raisins
pricing:
  type: single
  currency: USD
  price: 35
---
