---
name: Peach Velvet Cake
image: /uploads/peachCake.png
section: seasonal.md
badges:
  - organic.md
flavors:
  - Peach
pricing:
  type: single
  currency: USD
  price: 35
seasonal:
  start: 06-01
  end: 09-31
---
