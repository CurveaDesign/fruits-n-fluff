---
name: Autumn Breeze Cake
image: /uploads/appleCake.png
section: organic.md
badges:
  - organic.md
flavors:
  - Apple
  - Cinnamon
  - Walnuts
pricing:
  type: single
  currency: USD
  price: 35
---
