---
isActive: true
name: Kebbeh Tray
sectionRef: cateringSections/signature-trays
image: /uploads/placeholder.jpg
priceLabel: ""
order: 1
---
A refined classic, crafted for sharing.
