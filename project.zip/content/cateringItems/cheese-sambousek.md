---
isActive: true
name: Cheese Sambousek
sectionRef: cateringSections/mouajanat
image: /uploads/placeholder.jpg
priceLabel: ""
order: 2
---
Golden, crisp, and made for cozy cravings.
