---
name: Gentle Fudge Cake
image: /uploads/glutenfreeChocolateCake.png
section: gluten-free-lactose-free.md
badges:
  - organic.md
flavors:
  - Chocolate
pricing:
  type: single
  currency: USD
  price: 55
---
