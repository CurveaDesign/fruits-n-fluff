---
name: test cake
image: /uploads/automn-breeze_cake.jpg
section: vegan.md
badges:
  - gluten-free.md
  - lactose-free.md
flavors:
  - Apple
  - Cinammon
description: short description
pricing:
  type: by_size
  currency: USD
  sizes:
    - label: "24"
      price: 35
    - label: "26"
      price: 55
---
